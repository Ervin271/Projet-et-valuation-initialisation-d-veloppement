"""Algèbre linéaire écrite à la main (sans numpy).

Les fonctions marchent avec des flottants ET avec des Fraction (calcul exact) :
on passe tol=0 pour le calcul exact.
"""

TOL_FLOTTANT = 1e-12


class MatriceSinguliere(Exception):
    """Levée quand un pivot est nul (ou plus petit que la tolérance)."""


def copie(A):
    return [ligne[:] for ligne in A]


def produit_matrice_vecteur(A, x):
    return [sum(a * xj for a, xj in zip(ligne, x)) for ligne in A]


def residu(A, x, b):
    """r = b - A x."""
    Ax = produit_matrice_vecteur(A, x)
    return [bi - axi for bi, axi in zip(b, Ax)]


def norme_inf_vecteur(v):
    return max(abs(vi) for vi in v)


def norme_inf_matrice(A):
    """Plus grande somme des valeurs absolues d'une ligne."""
    return max(sum(abs(a) for a in ligne) for ligne in A)


def resoudre_gauss(A, b, pivot=True, tol=TOL_FLOTTANT):
    """Résout A x = b par élimination de Gauss.

    pivot=True : pivot partiel (on prend la plus grande valeur absolue
    de la colonne). pivot=False : on prend toujours la diagonale.
    """
    n = len(A)
    M = copie(A)
    y = list(b)
    for k in range(n):
        if pivot:
            p = max(range(k, n), key=lambda i: abs(M[i][k]))
            if p != k:
                M[k], M[p] = M[p], M[k]
                y[k], y[p] = y[p], y[k]
        if abs(M[k][k]) <= tol:
            raise MatriceSinguliere(f"pivot nul à l'étape {k}")
        for i in range(k + 1, n):
            f = M[i][k] / M[k][k]
            if f != 0:
                for j in range(k, n):
                    M[i][j] -= f * M[k][j]
                y[i] -= f * y[k]
    x = [0] * n
    for i in range(n - 1, -1, -1):
        s = y[i] - sum(M[i][j] * x[j] for j in range(i + 1, n))
        x[i] = s / M[i][i]
    return x


def inverse(A, tol=TOL_FLOTTANT):
    """Inverse par résolution de n systèmes (colonnes de l'identité)."""
    n = len(A)
    colonnes = []
    for j in range(n):
        e = [1 if i == j else 0 for i in range(n)]
        colonnes.append(resoudre_gauss(A, e, tol=tol))
    return [[colonnes[j][i] for j in range(n)] for i in range(n)]


def conditionnement_inf(A, tol=TOL_FLOTTANT):
    """cond_inf(A) = ||A|| * ||A^-1|| (norme infinie)."""
    return norme_inf_matrice(A) * norme_inf_matrice(inverse(A, tol=tol))


def resoudre_tridiagonal(inf, diag, sup, d):
    """Algorithme de Thomas : système tridiagonal en O(n).

    inf[i] est sous la diagonale (ligne i, colonne i-1), inf[0] ignoré ;
    sup[i] est au-dessus (ligne i, colonne i+1), sup[n-1] ignoré.
    """
    n = len(diag)
    c = [0] * n
    r = [0] * n
    c[0] = sup[0] / diag[0] if n > 1 else 0
    r[0] = d[0] / diag[0]
    for i in range(1, n):
        denom = diag[i] - inf[i] * c[i - 1]
        if denom == 0:
            raise MatriceSinguliere(f"pivot nul à la ligne {i}")
        c[i] = sup[i] / denom if i < n - 1 else 0
        r[i] = (d[i] - inf[i] * r[i - 1]) / denom
    x = [0] * n
    x[-1] = r[-1]
    for i in range(n - 2, -1, -1):
        x[i] = r[i] - c[i] * x[i + 1]
    return x
