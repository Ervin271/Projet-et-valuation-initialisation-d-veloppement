"""Géométrie du plan appliquée à la courbe (spline) : intersections avec
une droite, point le plus proche, longueur, aire sous la courbe."""

import math

from interpolation import Spline
from polynomes import (derivee, horner, produit, racines_reelles, somme)


def intersections_droite(spline, m, p):
    """Points (x, y) où la courbe coupe la droite y = m x + p.

    Sur chaque segment, S(x) - (m x + p) est un polynôme de degré <= 3 en
    t = x - xs[i] : on cherche ses racines dans [0, largeur].
    """
    points = []
    for i, seg in enumerate(spline.segments):
        x0 = spline.xs[i]
        # droite exprimée en t : m (x0 + t) + p
        droite = [m * x0 + p, m, 0, 0]
        poly = somme(seg, [-c for c in droite])
        for t in racines_reelles(poly, 0, spline.largeur(i)):
            x = x0 + t
            if points and abs(x - points[-1][0]) < 1e-9:
                continue  # même point partagé entre deux segments
            points.append((x, spline(x)))
    return points


def intersections_horizontale(spline, y):
    return intersections_droite(spline, 0, y)


def point_le_plus_proche(spline, px, py):
    """Point de la courbe le plus proche de (px, py).

    La dérivée de la distance au carré est un polynôme de degré 5 en t ;
    on teste ses racines et les deux extrémités de chaque segment.
    Renvoie (x, y, distance).
    """
    meilleur = None
    for i, seg in enumerate(spline.segments):
        x0 = spline.xs[i]
        dx = [x0 - px, 1]                    # x(t) - px
        dy = somme(seg, [-py])               # y(t) - py
        dy_prime = derivee(seg)
        # d/dt [(dx)^2 + (dy)^2] / 2 = dx*1 + dy*y'
        g = somme(dx, produit(dy, dy_prime))
        candidats = [0, spline.largeur(i)]
        candidats += racines_reelles(g, 0, spline.largeur(i))
        for t in candidats:
            x = x0 + t
            y = horner(seg, t)
            dist = math.hypot(x - px, y - py)
            if meilleur is None or dist < meilleur[2]:
                meilleur = (x, y, dist)
    return meilleur


def longueur_arc(spline, pas_par_segment=200):
    """Longueur de la courbe (somme de petits segments de droite)."""
    total = 0.0
    for i, seg in enumerate(spline.segments):
        h = spline.largeur(i)
        prec = (0.0, seg[0])
        for k in range(1, pas_par_segment + 1):
            t = h * k / pas_par_segment
            cur = (t, horner(seg, t))
            total += math.hypot(cur[0] - prec[0], cur[1] - prec[1])
            prec = cur
    return total


def aire_sous_courbe(spline):
    """Intégrale EXACTE de la spline (on intègre chaque polynôme)."""
    total = 0.0
    for i, (a, b, c, d) in enumerate(spline.segments):
        h = spline.largeur(i)
        total += a * h + b * h ** 2 / 2 + c * h ** 3 / 3 + d * h ** 4 / 4
    return total


def aire_trapezes(spline, n=1000):
    """Aire sous la courbe par la méthode des trapèzes (pour comparer)."""
    a, b = spline.xs[0], spline.xs[-1]
    h = (b - a) / n
    s = (spline(a) + spline(b)) / 2
    for k in range(1, n):
        s += spline(a + k * h)
    return s * h
