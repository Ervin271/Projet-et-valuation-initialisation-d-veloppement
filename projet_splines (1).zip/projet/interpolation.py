"""Interpolation : polynôme de degré n et spline cubique naturelle."""

import math

from algebre import resoudre_gauss, resoudre_tridiagonal
from polynomes import horner


# ------------------------------------------------------- polynôme global

def matrice_vandermonde(xs):
    """V[i][j] = xs[i]**j."""
    n = len(xs)
    return [[x ** j for j in range(n)] for x in xs]


def interpolation_vandermonde(xs, ys, pivot=True, tol=1e-12):
    """Coefficients (puissances croissantes) du polynôme qui passe par
    les points (xs[i], ys[i]), en résolvant le système de Vandermonde."""
    return resoudre_gauss(matrice_vandermonde(xs), list(ys), pivot=pivot,
                          tol=tol)


def differences_divisees(xs, ys):
    """Coefficients de la forme de Newton."""
    n = len(xs)
    c = list(ys)
    for j in range(1, n):
        for i in range(n - 1, j - 1, -1):
            c[i] = (c[i] - c[i - 1]) / (xs[i] - xs[i - j])
    return c


def evaluer_newton(xs, c, x):
    """Évalue la forme de Newton (type Horner), numériquement stable."""
    r = c[-1]
    for i in range(len(c) - 2, -1, -1):
        r = r * (x - xs[i]) + c[i]
    return r


def noeuds_equidistants(n, a, b):
    return [a + (b - a) * i / (n - 1) for i in range(n)]


def noeuds_tchebychev(n, a, b):
    """Zéros du polynôme de Tchebychev, ramenés sur [a, b]."""
    return sorted((a + b) / 2 + (b - a) / 2 * math.cos((2 * k + 1) * math.pi
                                                       / (2 * n))
                  for k in range(n))


# --------------------------------------------------------------- spline

class Spline:
    """Spline cubique naturelle passant par (xs[i], ys[i]).

    Sur [xs[i], xs[i+1]] : S(x) = a + b t + c t^2 + d t^3, avec t = x - xs[i].
    """

    def __init__(self, xs, ys, methode="thomas"):
        if len(xs) < 2:
            raise ValueError("il faut au moins 2 points")
        if any(xs[i] >= xs[i + 1] for i in range(len(xs) - 1)):
            raise ValueError("les abscisses doivent être strictement croissantes")
        self.xs = list(xs)
        self.ys = list(ys)
        n = len(xs)
        h = [xs[i + 1] - xs[i] for i in range(n - 1)]
        # inconnues : c_0..c_{n-1} (c_0 = c_{n-1} = 0, spline naturelle)
        if n == 2:
            c = [0, 0]
        else:
            m = n - 2
            diag = [2 * (h[i] + h[i + 1]) for i in range(m)]
            inf = [0] + [h[i] for i in range(1, m)]
            sup = [h[i + 1] for i in range(m - 1)] + [0]
            rhs = [3 * ((ys[i + 2] - ys[i + 1]) / h[i + 1]
                        - (ys[i + 1] - ys[i]) / h[i]) for i in range(m)]
            if methode == "thomas":
                cint = resoudre_tridiagonal(inf, diag, sup, rhs)
            else:  # même système en matrice pleine, résolu par Gauss
                A = [[0] * m for _ in range(m)]
                for i in range(m):
                    A[i][i] = diag[i]
                    if i > 0:
                        A[i][i - 1] = inf[i]
                    if i < m - 1:
                        A[i][i + 1] = sup[i]
                cint = resoudre_gauss(A, rhs)
            c = [0] + cint + [0]
        self.segments = []  # (a, b, c, d) pour chaque intervalle
        for i in range(n - 1):
            b = (ys[i + 1] - ys[i]) / h[i] - h[i] * (2 * c[i] + c[i + 1]) / 3
            d = (c[i + 1] - c[i]) / (3 * h[i])
            self.segments.append([ys[i], b, c[i], d])

    def _indice(self, x):
        xs = self.xs
        if x <= xs[0]:
            return 0
        if x >= xs[-1]:
            return len(xs) - 2
        lo, hi = 0, len(xs) - 1
        while hi - lo > 1:  # recherche dichotomique
            mid = (lo + hi) // 2
            if xs[mid] <= x:
                lo = mid
            else:
                hi = mid
        return lo

    def __call__(self, x):
        i = self._indice(x)
        return horner(self.segments[i], x - self.xs[i])

    def pente(self, x):
        i = self._indice(x)
        a, b, c, d = self.segments[i]
        t = x - self.xs[i]
        return b + 2 * c * t + 3 * d * t * t

    def largeur(self, i):
        return self.xs[i + 1] - self.xs[i]
