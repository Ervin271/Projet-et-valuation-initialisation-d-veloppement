"""Affichage interactif : courbe spline, droite horizontale et point
le plus proche de la souris.

  - déplacer la souris : une droite horizontale suit la souris, ses
    intersections avec la courbe sont marquées en rouge, et le point de la
    courbe le plus proche de la souris est relié à celle-ci ;
  - clic gauche : ajoute un point de contrôle ;
  - clic droit : supprime le point de contrôle le plus proche
    (il en reste toujours au moins 3) ;
  - touche r : revient aux points de départ.
"""

import matplotlib.pyplot as plt

from geometrie import (aire_sous_courbe, intersections_horizontale,
                       longueur_arc, point_le_plus_proche)
from interpolation import Spline

POINTS_DEPART = [(0, 1), (1, 3), (2, 2), (3, 5), (4, 1), (5, 3), (6, 0.5)]
XMIN, XMAX, YMIN, YMAX = -0.5, 6.5, -1.5, 7.5
ECART_X_MIN = 0.05  # écart minimal entre deux abscisses


def construire(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return Spline(xs, ys)


def ajouter_point(points, x, y):
    """Ajoute (x, y) si l'abscisse reste à distance de celles existantes."""
    if any(abs(x - px) < ECART_X_MIN for px, _ in points):
        return False
    points.append((x, y))
    points.sort()
    return True


def supprimer_point_proche(points, x, y):
    if len(points) <= 3:
        return False
    i = min(range(len(points)),
            key=lambda k: (points[k][0] - x) ** 2 + (points[k][1] - y) ** 2)
    points.pop(i)
    return True


def courbe_echantillonnee(spline, par_segment=40):
    xs, ys = [], []
    for i in range(len(spline.xs) - 1):
        for k in range(par_segment):
            x = spline.xs[i] + spline.largeur(i) * k / par_segment
            xs.append(x)
            ys.append(spline(x))
    xs.append(spline.xs[-1])
    ys.append(spline(spline.xs[-1]))
    return xs, ys


def main():
    points = list(POINTS_DEPART)
    fig, ax = plt.subplots(figsize=(9, 6))
    fig.canvas.manager.set_window_title("Splines cubiques et racines")

    def dessiner(souris=None):
        ax.clear()
        ax.set_xlim(XMIN, XMAX)
        ax.set_ylim(YMIN, YMAX)
        ax.set_aspect("equal")
        ax.grid(True, alpha=0.3)
        spline = construire(points)
        cx, cy = courbe_echantillonnee(spline)
        ax.plot(cx, cy, "b-", lw=2)
        ax.plot([p[0] for p in points], [p[1] for p in points], "ks")
        titre = (f"{len(points)} points | longueur {longueur_arc(spline):.2f} "
                 f"| aire sous la courbe {aire_sous_courbe(spline):.2f}")
        if souris is not None:
            mx, my = souris
            ax.axhline(my, color="gray", ls="--", lw=1)
            inters = intersections_horizontale(spline, my)
            if inters:
                ax.plot([p[0] for p in inters], [p[1] for p in inters], "ro",
                        ms=8)
            x, y, d = point_le_plus_proche(spline, mx, my)
            ax.plot([mx, x], [my, y], "g-", lw=1.5)
            ax.plot([x], [y], "g^", ms=9)
            ax.plot([mx], [my], "k.")
            titre += (f"\ny = {my:.2f} : {len(inters)} intersection(s) "
                      f"| distance à la courbe {d:.3f}")
        ax.set_title(titre, fontsize=10)
        fig.canvas.draw_idle()

    def bouge(event):
        if event.inaxes is ax:
            dessiner((event.xdata, event.ydata))

    def clic(event):
        if event.inaxes is not ax:
            return
        if event.button == 1:
            ajoute = ajouter_point(points, event.xdata, event.ydata)
        elif event.button == 3:
            ajoute = supprimer_point_proche(points, event.xdata, event.ydata)
        else:
            return
        if ajoute:
            dessiner((event.xdata, event.ydata))

    def touche(event):
        if event.key == "r":
            points[:] = POINTS_DEPART
            dessiner()

    fig.canvas.mpl_connect("motion_notify_event", bouge)
    fig.canvas.mpl_connect("button_press_event", clic)
    fig.canvas.mpl_connect("key_press_event", touche)
    dessiner()
    plt.show()


if __name__ == "__main__":
    main()
