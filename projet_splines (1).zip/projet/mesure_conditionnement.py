"""Partie 1 : conditionnement et pivot (système de Vandermonde).

On interpole f(x) = 1/(1+x^2) sur n points équidistants de [0, 1] en
résolvant le système de Vandermonde. On compare :
  - Gauss avec pivot partiel (flottants),
  - Gauss sans pivot (flottants),
  - la référence exacte (Gauss avec Fraction).
"""

import csv
import os
from fractions import Fraction

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from algebre import (MatriceSinguliere, conditionnement_inf, resoudre_gauss)
from interpolation import matrice_vandermonde

DOSSIER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resultats")


def erreur_relative(approx, exact):
    num = max(abs(a - float(e)) for a, e in zip(approx, exact))
    den = max(abs(float(e)) for e in exact)
    return num / den


def etude_vandermonde(ns=range(3, 21)):
    lignes = []
    for n in ns:
        xs_f = [i / (n - 1) for i in range(n)]
        xs_q = [Fraction(i, n - 1) for i in range(n)]
        ys_q = [1 / (1 + x * x) for x in xs_q]
        ys_f = [float(y) for y in ys_q]
        A_q = matrice_vandermonde(xs_q)
        exact = resoudre_gauss(A_q, ys_q, tol=0)
        A_f = matrice_vandermonde(xs_f)
        cond = conditionnement_inf(A_f, tol=0)
        err_p = erreur_relative(resoudre_gauss(A_f, ys_f, tol=0), exact)
        try:
            err_s = erreur_relative(resoudre_gauss(A_f, ys_f, pivot=False, tol=0),
                                    exact)
        except MatriceSinguliere:
            err_s = float("nan")
        lignes.append((n, cond, err_p, err_s))
    return lignes


def cas_pivot_nul(eps_liste=(1e-5, 1e-10, 1e-15, 1e-20)):
    """Système 2x2 [[eps, 1], [1, 1]] x = [1, 2].

    Solution exacte : x0 = 1/(1-eps), x1 = (1-2 eps)/(1-eps), calculée
    avec Fraction pour mesurer l'erreur des deux variantes.
    """
    res = []
    for eps in eps_liste:
        A = [[eps, 1.0], [1.0, 1.0]]
        b = [1.0, 2.0]
        x_p = resoudre_gauss(A, b, pivot=True, tol=0)
        x_s = resoudre_gauss(A, b, pivot=False, tol=0)
        e = Fraction(eps)
        x0 = float(1 / (1 - e))
        res.append((eps, abs(x_p[0] - x0), abs(x_s[0] - x0)))
    return res


def main():
    os.makedirs(DOSSIER, exist_ok=True)
    lignes = etude_vandermonde()
    with open(os.path.join(DOSSIER, "conditionnement.csv"), "w",
              newline="") as f:
        w = csv.writer(f)
        w.writerow(["n", "cond_inf", "erreur_pivot", "erreur_sans_pivot"])
        w.writerows(lignes)
    print(f"{'n':>3} {'cond(V)':>12} {'err. pivot':>12} {'err. sans pivot':>16}")
    for n, c, ep, es in lignes:
        print(f"{n:>3} {c:>12.3e} {ep:>12.3e} {es:>16.3e}")

    print("\nPetit pivot : erreur sur x[0] (référence exacte) pour [[eps,1],[1,1]] x = [1,2]")
    pivots = cas_pivot_nul()
    with open(os.path.join(DOSSIER, "petit_pivot.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["eps", "erreur_pivot", "erreur_sans_pivot"])
        w.writerows(pivots)
    for eps, ep, es in pivots:
        print(f"eps={eps:.0e}  avec pivot: {ep:.2e}  sans pivot: {es:.2e}")

    plt.figure(figsize=(7, 4.5))
    ns = [l[0] for l in lignes]
    plt.semilogy(ns, [l[2] for l in lignes], "o-", label="erreur (pivot)")
    plt.semilogy(ns, [l[3] for l in lignes], "s--", label="erreur (sans pivot)")
    plt.semilogy(ns, [l[1] * 1.1e-16 for l in lignes], ":",
                 label="cond(V) x 1e-16 (borne théorique)")
    plt.xlabel("nombre de points n")
    plt.ylabel("erreur relative sur les coefficients")
    plt.title("Système de Vandermonde : l'erreur suit le conditionnement")
    plt.legend()
    plt.grid(True, which="both", alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(DOSSIER, "conditionnement.png"), dpi=120)


if __name__ == "__main__":
    main()
