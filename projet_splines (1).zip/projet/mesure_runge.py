"""Partie 2 : phénomène de Runge, spline, et coût de calcul.

2a. Erreur max de l'interpolation de f(x) = 1/(1+25 x^2) sur [-1, 1] :
    polynôme (noeuds équidistants), polynôme (noeuds de Tchebychev), spline.
2b. Temps de calcul : même système de spline résolu par Gauss (O(n^3))
    ou par l'algorithme de Thomas (O(n)).
"""

import csv
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from interpolation import (Spline, differences_divisees, evaluer_newton,
                           noeuds_equidistants, noeuds_tchebychev)

DOSSIER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resultats")


def f(x):
    return 1 / (1 + 25 * x * x)


def grille(m=2001):
    return [-1 + 2 * i / (m - 1) for i in range(m)]


def erreur_max(approx, pts):
    return max(abs(approx(x) - f(x)) for x in pts)


def erreurs(n, pts):
    xs = noeuds_equidistants(n, -1, 1)
    c = differences_divisees(xs, [f(x) for x in xs])
    e_equi = erreur_max(lambda x: evaluer_newton(xs, c, x), pts)
    xt = noeuds_tchebychev(n, -1, 1)
    ct = differences_divisees(xt, [f(x) for x in xt])
    e_tcheb = erreur_max(lambda x: evaluer_newton(xt, ct, x), pts)
    s = Spline(xs, [f(x) for x in xs])
    e_spl = erreur_max(s, pts)
    return e_equi, e_tcheb, e_spl


def temps(fn, repetitions):
    debut = time.perf_counter()
    for _ in range(repetitions):
        fn()
    return (time.perf_counter() - debut) / repetitions * 1000  # ms


def main():
    os.makedirs(DOSSIER, exist_ok=True)
    pts = grille()
    ns = [5, 7, 9, 11, 13, 15, 17, 21, 25, 31, 41]
    lignes = [(n,) + erreurs(n, pts) for n in ns]
    with open(os.path.join(DOSSIER, "runge.csv"), "w", newline="") as fcsv:
        w = csv.writer(fcsv)
        w.writerow(["n", "equidistants", "tchebychev", "spline"])
        w.writerows(lignes)
    print("2a. Erreur maximale sur [-1, 1]")
    print(f"{'n':>3} {'équidist.':>12} {'Tchebychev':>12} {'spline':>12}")
    for n, a, b, c in lignes:
        print(f"{n:>3} {a:>12.3e} {b:>12.3e} {c:>12.3e}")

    plt.figure(figsize=(7, 4.5))
    plt.semilogy([l[0] for l in lignes], [l[1] for l in lignes], "o-",
                 label="polynôme, noeuds équidistants")
    plt.semilogy([l[0] for l in lignes], [l[2] for l in lignes], "s-",
                 label="polynôme, noeuds de Tchebychev")
    plt.semilogy([l[0] for l in lignes], [l[3] for l in lignes], "^-",
                 label="spline cubique")
    plt.xlabel("nombre de points n")
    plt.ylabel("erreur maximale")
    plt.title("Phénomène de Runge : f(x) = 1/(1+25x²)")
    plt.legend()
    plt.grid(True, which="both", alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(DOSSIER, "runge.png"), dpi=120)

    # 2b : temps de calcul de la spline
    print("\n2b. Temps de construction de la spline (ms, varie selon la machine)")
    print(f"{'points':>7} {'Thomas':>10} {'Gauss':>10}")
    tl = []
    for n in [10, 20, 40, 80, 160]:
        xs = noeuds_equidistants(n, -1, 1)
        ys = [f(x) for x in xs]
        rep = 20 if n <= 40 else 3
        t_th = temps(lambda: Spline(xs, ys, "thomas"), rep)
        t_ga = temps(lambda: Spline(xs, ys, "gauss"), rep)
        tl.append((n, t_th, t_ga))
        print(f"{n:>7} {t_th:>10.3f} {t_ga:>10.3f}")
    with open(os.path.join(DOSSIER, "temps_spline.csv"), "w",
              newline="") as fcsv:
        w = csv.writer(fcsv)
        w.writerow(["points", "thomas_ms", "gauss_ms"])
        w.writerows(tl)

    plt.figure(figsize=(7, 4.5))
    plt.loglog([t[0] for t in tl], [t[1] for t in tl], "o-", label="Thomas")
    plt.loglog([t[0] for t in tl], [t[2] for t in tl], "s-", label="Gauss")
    plt.xlabel("nombre de points")
    plt.ylabel("temps (ms)")
    plt.title("Coût de la construction d'une spline")
    plt.legend()
    plt.grid(True, which="both", alpha=0.3)
    plt.tight_layout()
    plt.savefig(os.path.join(DOSSIER, "temps_spline.png"), dpi=120)


if __name__ == "__main__":
    main()
