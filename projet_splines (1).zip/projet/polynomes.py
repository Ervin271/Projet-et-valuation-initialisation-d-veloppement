"""Polynômes et recherche de racines.

Un polynôme est une liste de coefficients par puissances CROISSANTES :
[a0, a1, a2] représente a0 + a1 x + a2 x^2.
Les fonctions marchent aussi avec des Fraction (calcul exact).
"""


from fractions import Fraction


def _quotient(a, b):
    """a / b, exact (Fraction) si a et b sont deux entiers."""
    if isinstance(a, int) and isinstance(b, int):
        return Fraction(a, b)
    return a / b


def nettoyer(p):
    """Retire les coefficients nuls de tête (degré le plus haut)."""
    p = list(p)
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return p


def degre(p):
    return len(nettoyer(p)) - 1


def horner(p, x):
    """Évalue p(x) avec le schéma de Horner (n multiplications)."""
    r = 0
    for a in reversed(p):
        r = r * x + a
    return r


def evaluation_naive(p, x):
    """Évalue p(x) terme à terme avec x**k (pour comparer à Horner)."""
    return sum(a * x ** k for k, a in enumerate(p))


def derivee(p):
    if len(p) <= 1:
        return [0]
    return [k * a for k, a in enumerate(p)][1:]


def somme(p, q):
    n = max(len(p), len(q))
    return [(p[i] if i < len(p) else 0) + (q[i] if i < len(q) else 0)
            for i in range(n)]


def oppose(p):
    return [-a for a in p]


def produit(p, q):
    r = [0] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            r[i + j] += a * b
    return r


def depuis_racines(racines):
    """Polynôme unitaire (x - r1)(x - r2)..."""
    p = [1]
    for r in racines:
        p = produit(p, [-r, 1])
    return p


def division_euclidienne(p, q):
    """Renvoie (quotient, reste) de p par q."""
    p = nettoyer(p)
    q = nettoyer(q)
    if len(q) == 1 and q[0] == 0:
        raise ZeroDivisionError("division par le polynôme nul")
    r = list(p)
    quo = [0] * max(1, len(p) - len(q) + 1)
    while len(r) >= len(q) and not (len(r) == 1 and r[0] == 0):
        k = len(r) - len(q)
        c = _quotient(r[-1], q[-1])
        quo[k] = c
        for i, b in enumerate(q):
            r[i + k] -= c * b
        r.pop()
        if not r:
            r = [0]
            break
    return quo, nettoyer(r) if r else [0]


# ---------------------------------------------------------------- racines

def bissection(f, a, b, tol=1e-12, max_iter=200):
    """Racine de f dans [a, b] (f(a) et f(b) de signes opposés).

    Renvoie (racine, nombre d'itérations).
    """
    fa, fb = f(a), f(b)
    if fa == 0:
        return a, 0
    if fb == 0:
        return b, 0
    if fa * fb > 0:
        raise ValueError("f(a) et f(b) doivent être de signes opposés")
    for it in range(1, max_iter + 1):
        m = (a + b) / 2
        fm = f(m)
        if fm == 0 or (b - a) / 2 < tol:
            return m, it
        if fa * fm < 0:
            b, fb = m, fm
        else:
            a, fa = m, fm
    return (a + b) / 2, max_iter


def newton(f, df, x0, tol=1e-12, max_iter=100):
    """Méthode de Newton. Renvoie (racine, itérations) ou (None, max_iter)."""
    x = x0
    for it in range(1, max_iter + 1):
        d = df(x)
        if d == 0:
            return None, it
        x_new = x - f(x) / d
        if abs(x_new - x) < tol:
            return x_new, it
        x = x_new
    return None, max_iter


def racines_reelles(p, a, b, tol_racine=1e-12, tol_double=1e-9):
    """Racines réelles DISTINCTES de p dans [a, b], triées.

    Principe : entre deux points critiques consécutifs (racines de p'),
    p est monotone, donc il a au plus une racine, trouvée par bissection.
    Les points critiques sont obtenus récursivement.
    Un point critique où |p| <= tol_double est pris comme racine double.
    """
    p = nettoyer(p)
    d = len(p) - 1
    if d <= 0:
        return []
    if d == 1:
        r = -p[0] / p[1]
        return [r] if a <= r <= b else []
    crit = racines_reelles(derivee(p), a, b, tol_racine, tol_double)
    echelle = max(abs(c) for c in p)
    seuil = tol_double * echelle * 1e-3
    points = [a] + crit + [b]
    valeurs = [horner(p, x) for x in points]
    racines = []
    for i, x in enumerate(points):
        v = valeurs[i]
        if v == 0:
            racines.append(x)
        elif 0 < i < len(points) - 1 and abs(v) <= seuil:
            # point critique quasi nul : racine double si p ne change pas
            # de signe de part et d'autre (sinon la bissection trouvera
            # les deux racines proches)
            if v * valeurs[i - 1] > 0 and v * valeurs[i + 1] > 0:
                racines.append(x)
    for i in range(len(points) - 1):
        if valeurs[i] * valeurs[i + 1] < 0:
            r, _ = bissection(lambda x: horner(p, x), points[i], points[i + 1],
                              tol_racine)
            racines.append(r)
    racines.sort()
    # fusion des doublons très proches
    res = []
    for r in racines:
        if not res or abs(r - res[-1]) > 1e-9:
            res.append(r)
    return res


# ----------------------------------------------------------- Sturm (exact)

def suite_sturm(p):
    p = nettoyer(p)
    suite = [p, nettoyer(derivee(p))]
    while len(suite[-1]) > 1 or suite[-1][0] != 0:
        _, r = division_euclidienne(suite[-2], suite[-1])
        if len(r) == 1 and r[0] == 0:
            break
        suite.append(oppose(r))
    return suite


def _variations(valeurs):
    s = [v for v in valeurs if v != 0]
    return sum(1 for i in range(len(s) - 1) if s[i] * s[i + 1] < 0)


def nombre_racines_sturm(p, a, b):
    """Nombre de racines réelles DISTINCTES de p dans ]a, b] (calcul exact
    si les coefficients et a, b sont des Fraction)."""
    suite = suite_sturm(p)
    va = _variations([horner(q, a) for q in suite])
    vb = _variations([horner(q, b) for q in suite])
    return va - vb
