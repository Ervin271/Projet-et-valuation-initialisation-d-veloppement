"""Tests automatiques : python -m unittest test_courbes -v"""

import math
import unittest
from fractions import Fraction as F

from algebre import (MatriceSinguliere, conditionnement_inf, resoudre_gauss,
                     resoudre_tridiagonal, residu, norme_inf_vecteur)
from geometrie import (aire_sous_courbe, aire_trapezes,
                       intersections_droite, intersections_horizontale,
                       point_le_plus_proche)
from interpolation import (Spline, differences_divisees, evaluer_newton,
                           interpolation_vandermonde, noeuds_tchebychev)
from polynomes import (bissection, depuis_racines, derivee, division_euclidienne,
                       horner, newton, nombre_racines_sturm, produit,
                       racines_reelles)


class TestAlgebre(unittest.TestCase):
    def test_gauss_systeme_simple(self):
        x = resoudre_gauss([[2, 1], [1, 3]], [5, 10])
        self.assertAlmostEqual(x[0], 1)
        self.assertAlmostEqual(x[1], 3)

    def test_gauss_exact_fraction(self):
        x = resoudre_gauss([[F(2), F(1)], [F(1), F(3)]], [F(5), F(10)], tol=0)
        self.assertEqual(x, [F(1), F(3)])

    def test_matrice_singuliere(self):
        with self.assertRaises(MatriceSinguliere):
            resoudre_gauss([[1, 2], [2, 4]], [1, 2])

    def test_pivot_evite_petit_pivot(self):
        A, b = [[1e-20, 1.0], [1.0, 1.0]], [1.0, 2.0]
        avec = resoudre_gauss(A, b, pivot=True, tol=0)
        sans = resoudre_gauss(A, b, pivot=False, tol=0)
        self.assertAlmostEqual(avec[0], 1.0)
        self.assertGreater(abs(sans[0] - 1.0), 0.5)

    def test_thomas_egal_gauss(self):
        inf, diag, sup, d = [0, 1, 1], [4, 4, 4], [1, 1, 0], [6, 12, 14]
        A = [[4, 1, 0], [1, 4, 1], [0, 1, 4]]
        x1 = resoudre_tridiagonal(inf, diag, sup, d)
        x2 = resoudre_gauss(A, d)
        for a, b in zip(x1, x2):
            self.assertAlmostEqual(a, b)

    def test_residu_petit(self):
        A = [[3.0, 1.0, 0.0], [1.0, 4.0, 1.0], [0.0, 1.0, 5.0]]
        b = [1.0, 2.0, 3.0]
        x = resoudre_gauss(A, b)
        self.assertLess(norme_inf_vecteur(residu(A, x, b)), 1e-14)

    def test_conditionnement_identite(self):
        self.assertAlmostEqual(conditionnement_inf([[1, 0], [0, 1]]), 1.0)


class TestPolynomes(unittest.TestCase):
    def test_horner(self):
        self.assertEqual(horner([1, 2, 3], 2), 1 + 4 + 12)

    def test_derivee_produit(self):
        self.assertEqual(derivee([5, 3, 2]), [3, 4])
        self.assertEqual(produit([1, 1], [1, 1]), [1, 2, 1])

    def test_division_exacte(self):
        q, r = division_euclidienne([F(-1), F(0), F(1)], [F(-1), F(1)])
        self.assertEqual(q, [F(1), F(1)])
        self.assertEqual(r, [F(0)])

    def test_bissection_et_newton(self):
        f = lambda x: x * x - 2
        rb, _ = bissection(f, 1, 2)
        rn, _ = newton(f, lambda x: 2 * x, 1.5)
        self.assertAlmostEqual(rb, math.sqrt(2), places=10)
        self.assertAlmostEqual(rn, math.sqrt(2), places=10)

    def test_bissection_meme_signe(self):
        with self.assertRaises(ValueError):
            bissection(lambda x: x * x + 1, 0, 1)

    def test_racines_reelles(self):
        r = racines_reelles(depuis_racines([1, 2, 3]), 0, 4)
        self.assertEqual(len(r), 3)
        for a, b in zip(r, [1, 2, 3]):
            self.assertAlmostEqual(a, b, places=9)

    def test_racine_double(self):
        self.assertEqual(len(racines_reelles(depuis_racines([1, 1, 3]), 0, 5)), 2)

    def test_sturm_exact(self):
        p = depuis_racines([F(1), F(1), F(3)])
        self.assertEqual(nombre_racines_sturm(p, F(0), F(5)), 2)
        self.assertEqual(nombre_racines_sturm([F(1), F(0), F(1)], F(-9), F(9)), 0)


class TestInterpolation(unittest.TestCase):
    def test_vandermonde_retrouve_polynome(self):
        xs = [0.0, 1.0, 2.0, 3.0]
        ys = [1 + 2 * x + 3 * x ** 3 for x in xs]
        c = interpolation_vandermonde(xs, ys)
        for a, b in zip(c, [1, 2, 0, 3]):
            self.assertAlmostEqual(a, b, places=9)

    def test_newton_passe_par_les_points(self):
        xs = noeuds_tchebychev(6, -1, 1)
        ys = [math.sin(x) for x in xs]
        c = differences_divisees(xs, ys)
        for x, y in zip(xs, ys):
            self.assertAlmostEqual(evaluer_newton(xs, c, x), y, places=12)

    def test_spline_passe_par_les_points(self):
        xs, ys = [0, 1, 2, 3, 4], [0, 2, 1, 3, 0]
        s = Spline(xs, ys)
        for x, y in zip(xs, ys):
            self.assertAlmostEqual(s(x), y, places=12)

    def test_spline_continuite_pente(self):
        s = Spline([0, 1, 2, 3], [0, 2, 1, 3])
        for xi in (1, 2):
            self.assertAlmostEqual(s.pente(xi - 1e-9), s.pente(xi + 1e-9),
                                   places=6)

    def test_spline_abscisses_non_croissantes(self):
        with self.assertRaises(ValueError):
            Spline([0, 2, 1], [0, 1, 2])

    def test_spline_thomas_egal_gauss(self):
        xs, ys = [0, 1, 2, 3, 4, 5], [0, 2, 1, 3, 0, 2]
        a, b = Spline(xs, ys, "thomas"), Spline(xs, ys, "gauss")
        for k in range(51):
            self.assertAlmostEqual(a(k / 10), b(k / 10), places=10)


class TestGeometrie(unittest.TestCase):
    def setUp(self):
        self.s = Spline([0, 1, 2, 3, 4], [0, 2, 1, 3, 0])

    def test_intersections_sur_la_droite(self):
        for x, y in intersections_horizontale(self.s, 1.5):
            self.assertAlmostEqual(y, 1.5, places=9)
            self.assertAlmostEqual(self.s(x), 1.5, places=9)

    def test_droite_oblique(self):
        for x, y in intersections_droite(self.s, 0.5, 0.2):
            self.assertAlmostEqual(y, 0.5 * x + 0.2, places=9)

    def test_niveau_hors_courbe(self):
        self.assertEqual(intersections_horizontale(self.s, 100), [])

    def test_point_le_plus_proche_force_brute(self):
        px, py = 2.5, 5.0
        _, _, d = point_le_plus_proche(self.s, px, py)
        brute = min(math.hypot(k / 2000 * 4 - px, self.s(k / 2000 * 4) - py)
                    for k in range(2001))
        self.assertLessEqual(d, brute + 1e-12)
        self.assertAlmostEqual(d, brute, places=4)

    def test_aire_exacte_contre_trapezes(self):
        self.assertAlmostEqual(aire_sous_courbe(self.s),
                               aire_trapezes(self.s, 20000), places=5)


if __name__ == "__main__":
    unittest.main()
