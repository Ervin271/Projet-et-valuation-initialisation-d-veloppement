"""Partie 3 : recherche de racines, calcul exact (Fraction) et cas limites.

3a. Bissection contre Newton (vitesse, échecs).
3b. Polynôme de Wilkinson : coefficients en flottants contre exact.
3c. Cas limites : racines multiples, racines très proches (Sturm exact).
3d. Intersections courbe / droite : compte en flottants contre compte exact.
"""

import csv
import os
import random
from fractions import Fraction

from geometrie import intersections_horizontale
from interpolation import Spline
from polynomes import (bissection, depuis_racines, derivee, horner, newton,
                       nombre_racines_sturm, racines_reelles)

DOSSIER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resultats")


def etude_bissection_newton():
    lignes = []
    cas = [
        ("x^2 - 2 sur [1, 2]", [-2, 0, 1], 1.0, 2.0, 1.5),
        ("x^3 - 2x - 5 sur [2, 3]", [-5, -2, 0, 1], 2.0, 3.0, 2.5),
        ("(x-1)^2 (x+2) sur [0, 3] (racine double)",
         depuis_racines([1, 1, -2]), 0.0, 3.0, 3.0),
        ("x^3 - 2x + 2 sur [-3, 0] (Newton cycle depuis 0)",
         [2, -2, 0, 1], -3.0, 0.0, 0.0),
    ]
    for nom, p, a, b, x0 in cas:
        fp = lambda x, p=p: horner(p, x)
        dp = derivee(p)
        dfp = lambda x, dp=dp: horner(dp, x)
        try:
            rb, ib = bissection(fp, a, b, tol=1e-12)
            sb = f"{ib}"
        except ValueError:
            rb, sb = None, "pas de changement de signe"
        rn, inn = newton(fp, dfp, x0, tol=1e-12)
        sn = f"{inn}" if rn is not None else f"échec ({inn} it.)"
        lignes.append((nom, sb, sn))
    return lignes


def wilkinson(n):
    """Racines entières 1..n : coefficients exacts (Fraction) et flottants."""
    p_exact = depuis_racines([Fraction(k) for k in range(1, n + 1)])
    p_float = [float(c) for c in p_exact]
    return p_exact, p_float


def etude_wilkinson(degres=(5, 10, 13, 15, 17, 20)):
    lignes = []
    for n in degres:
        p_exact, p_float = wilkinson(n)
        compte_exact = nombre_racines_sturm(p_exact, Fraction(0),
                                            Fraction(n) + Fraction(1, 2))
        trouvees = racines_reelles(p_float, 0, n + 0.5)
        # erreur sur chaque racine k : plus petit écart à k
        if len(trouvees) == n:
            err = max(abs(r - (k + 1)) for k, r in enumerate(trouvees))
        else:
            err = max(min(abs(r - k) for r in trouvees) if trouvees else
                      float("inf") for k in range(1, n + 1))
        lignes.append((n, compte_exact, len(trouvees), err))
    return lignes


def cas_limites():
    F = Fraction
    cas = [
        ("(x-1)(x-3)", [F(1), F(3)]),
        ("(x-1)^2 (x-3) : racine double", [F(1), F(1), F(3)]),
        ("(x-1)^3 : racine triple", [F(1)] * 3),
        ("(x-1)(x-1,000001) : racines très proches", [F(1), F(1000001, 1000000)]),
        ("(x-1)(x-1-1e-12) : racines trop proches", [F(1), F(1) + F(1, 10 ** 12)]),
        ("x^2 + 1 : aucune racine réelle", None),
    ]
    lignes = []
    for nom, racines in cas:
        if racines is None:
            p_exact = [F(1), F(0), F(1)]
        else:
            p_exact = depuis_racines(racines)
        p_float = [float(c) for c in p_exact]
        exact = nombre_racines_sturm(p_exact, F(0), F(5))
        flot = len(racines_reelles(p_float, 0, 5))
        lignes.append((nom, exact, flot))
    return lignes


def etude_intersections(nb_niveaux=40, graine=2024):
    """Compare le nombre d'intersections trouvé en flottants avec le nombre
    exact (Sturm sur des Fraction) pour des niveaux horizontaux y = h."""
    rnd = random.Random(graine)
    n = 8
    xs_q = [Fraction(i) for i in range(n)]
    ys_q = [Fraction(rnd.randint(0, 10)) for _ in range(n)]
    sp_q = Spline(xs_q, ys_q)
    sp_f = Spline([float(x) for x in xs_q], [float(y) for y in ys_q])

    niveaux = [Fraction(rnd.randint(0, 40), 4) for _ in range(nb_niveaux)]
    niveaux += [y for y in ys_q[1:-1]]  # niveaux pile sur des noeuds
    diff = []
    for h in niveaux:
        exact = 1 if sp_q(xs_q[0]) == h else 0
        for i, seg in enumerate(sp_q.segments):
            p = [seg[0] - h] + list(seg[1:])
            exact += nombre_racines_sturm(p, Fraction(0), sp_q.largeur(i))
        flot = len(intersections_horizontale(sp_f, float(h)))
        if exact != flot:
            diff.append((h, exact, flot))
    return len(niveaux), diff


def main():
    os.makedirs(DOSSIER, exist_ok=True)
    print("3a. Bissection contre Newton (tolérance 1e-12)")
    res_a = etude_bissection_newton()
    for nom, sb, sn in res_a:
        print(f"  {nom:55s} bissection: {sb:>28s} | Newton: {sn}")

    print("\n3b. Polynôme de Wilkinson (racines 1..n), flottants contre exact")
    res_b = etude_wilkinson()
    print(f"  {'n':>3} {'racines exactes':>16} {'trouvées (float)':>17} "
          f"{'erreur max':>12}")
    for n, ex, fl, err in res_b:
        print(f"  {n:>3} {ex:>16} {fl:>17} {err:>12.2e}")

    print("\n3c. Cas limites dans [0, 5] : compte exact (Sturm) / flottants")
    res_c = cas_limites()
    for nom, ex, fl in res_c:
        print(f"  {nom:50s} exact: {ex}  flottants: {fl}")

    print("\n3d. Intersections courbe / droite horizontale")
    total, diff = etude_intersections()
    print(f"  {total} niveaux testés, {len(diff)} désaccord(s) "
          f"avec le compte exact")
    for h, ex, fl in diff:
        print(f"    niveau {h} : exact {ex}, flottants {fl}")

    with open(os.path.join(DOSSIER, "racines.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["cas", "exact", "flottants"])
        w.writerows(res_c)
        w.writerow([])
        w.writerow(["wilkinson_n", "exact", "trouvees", "erreur_max"])
        w.writerows(res_b)


if __name__ == "__main__":
    main()
